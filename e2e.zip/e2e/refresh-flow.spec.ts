import { test, expect } from '@playwright/test';

function base64Url(input: string) {
  return Buffer.from(input).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

function fakeJwt(payload: object) {
  const header = base64Url(JSON.stringify({ alg: 'none', typ: 'JWT' }));
  const body = base64Url(JSON.stringify(payload));
  return `${header}.${body}.`;
}

test('refresh on 401 triggers retry and updates UI', async ({ page }) => {
  const now = Math.floor(Date.now() / 1000);
  const expiredToken = fakeJwt({
    sub: '1',
    name: 'Aluno Expirando',
    preferred_username: 'aluno',
    email: 'aluno@example.com',
    realm_access: { roles: ['aluno'] },
    exp: now - 10, // expirado
  });
  const refreshedToken = fakeJwt({
    sub: '1',
    name: 'Aluno Novo',
    preferred_username: 'aluno',
    email: 'aluno@example.com',
    realm_access: { roles: ['aluno'] },
    exp: now + 3600,
  });

  await page.addInitScript(([t]) => {
    window.localStorage.setItem('token', t as string);
    window.localStorage.setItem('refresh_token', 'dummy');
  }, [expiredToken]);

  let dashboardCalls = 0;
  await page.route('**/api/dashboard/aluno', async (route) => {
    dashboardCalls++;
    if (dashboardCalls === 1) {
      await route.fulfill({ status: 401, contentType: 'application/json', body: JSON.stringify({ error: 'unauthorized' }) });
    } else {
      await route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ ok: true, via: 'retry' }) });
    }
  });

  await page.route('**/api/auth/refresh', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ access_token: refreshedToken, refresh_token: 'dummy2' })
    });
  });

  await page.goto('/dashboard-aluno');

  // Após o retry bem-sucedido, o JSON do dashboard deve aparecer
  await expect(page.locator('pre')).toContainText('"ok": true');
});
