import { test } from '@playwright/test';

// Login/Register agora redirecionam para o Keycloak nativo, então não há mais formulário SPA para validar aqui.
test.describe.skip('Login Page (SPA form removed)', () => {
  test('skipped: login handled by Keycloak', async () => {});
});
