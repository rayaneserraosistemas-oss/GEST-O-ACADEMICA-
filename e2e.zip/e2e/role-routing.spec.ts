import { test, expect } from '@playwright/test';

function base64Url(input: string) {
  return Buffer.from(input).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

function fakeJwt(payload: object) {
  const header = base64Url(JSON.stringify({ alg: 'none', typ: 'JWT' }));
  const body = base64Url(JSON.stringify(payload));
  return `${header}.${body}.`;
}

test.describe('Role based routing', () => {
  test('professor goes to /dashboard-professor', async ({ page }) => {
    const now = Math.floor(Date.now() / 1000);
    const token = fakeJwt({
      sub: '2',
      name: 'Teste Professor',
      preferred_username: 'prof',
      email: 'prof@example.com',
      realm_access: { roles: ['professor'] },
      exp: now + 3600,
    });

    await page.addInitScript(([t]) => {
      window.localStorage.setItem('token', t as string);
    }, [token]);

    await page.goto('/login');
    await page.waitForURL('**/dashboard-professor');
    await expect(page.url()).toMatch(/dashboard-professor$/);
  });

  test('coordenador goes to /dashboard-coordenador', async ({ page }) => {
    const now = Math.floor(Date.now() / 1000);
    const token = fakeJwt({
      sub: '3',
      name: 'Teste Coordenador',
      preferred_username: 'coord',
      email: 'coord@example.com',
      realm_access: { roles: ['coordenador'] },
      exp: now + 3600,
    });

    await page.addInitScript(([t]) => {
      window.localStorage.setItem('token', t as string);
    }, [token]);

    await page.goto('/login');
    await page.waitForURL('**/dashboard-coordenador');
    await expect(page.url()).toMatch(/dashboard-coordenador$/);
  });
});
