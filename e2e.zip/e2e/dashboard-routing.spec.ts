import { test, expect } from '@playwright/test';

// Utilitário para criar um JWT sem assinatura válido o suficiente para a app (somente decodificação do payload)
function base64Url(input: string) {
  return Buffer.from(input).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

function fakeJwt(payload: object) {
  const header = base64Url(JSON.stringify({ alg: 'none', typ: 'JWT' }));
  const body = base64Url(JSON.stringify(payload));
  return `${header}.${body}.`; // assinatura vazia
}

test.describe('Dashboard routing by role', () => {
  test('aluno should go to /dashboard-aluno', async ({ page }) => {
    const now = Math.floor(Date.now() / 1000);
    const token = fakeJwt({
      sub: '1',
      name: 'Teste Aluno',
      preferred_username: 'aluno',
      email: 'aluno@example.com',
      realm_access: { roles: ['aluno'] },
      exp: now + 3600,
    });

    await page.addInitScript(([t]) => {
      window.localStorage.setItem('token', t as string);
    }, [token]);

    await page.goto('/login');
    await page.waitForURL('**/dashboard-aluno');
    await expect(page.url()).toMatch(/dashboard-aluno$/);
  });
});
