import { test, expect, request as playwrightRequest } from '@playwright/test';

const API_URL = process.env.API_URL || 'http://localhost:8080';

// Only run this smoke test when API_SMOKE=1 is set
const run = process.env.API_SMOKE === '1' || process.env.API_SMOKE === 'true';
(run ? test : test.skip)('API health responds 200 { status: "ok" }', async ({ request }) => {
  const res = await request.get(`${API_URL}/api/health`);
  expect(res.ok()).toBeTruthy();
  const json = await res.json();
  expect(json).toMatchObject({ status: 'ok' });
});
