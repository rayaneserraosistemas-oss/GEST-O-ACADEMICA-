import { test, expect } from '@playwright/test';

function base64Url(input: string) {
  return Buffer.from(input).toString('base64').replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
}

function fakeJwt(payload: object) {
  const header = base64Url(JSON.stringify({ alg: 'none', typ: 'JWT' }));
  const body = base64Url(JSON.stringify(payload));
  return `${header}.${body}.`;
}

// Logout should clear session and redirect to /login

test('logout redirects to /login', async ({ page }) => {
  const now = Math.floor(Date.now() / 1000);
  const token = fakeJwt({
    sub: '1',
    name: 'Aluno Teste',
    preferred_username: 'aluno',
    email: 'aluno@example.com',
    realm_access: { roles: ['aluno'] },
    exp: now + 3600,
  });

  await page.addInitScript(([t]) => {
    window.localStorage.setItem('token', t as string);
  }, [token]);

  await page.goto('/dashboard-aluno');
  await page.getByRole('button', { name: 'Sair' }).click();
  await page.waitForURL('**/login');
  await expect(page.url()).toMatch(/\/login$/);
});
