# Runs the Quarkus backend using default profile (requires Keycloak) on port 8080 by default
# Requires Java 21 on PATH. You can override the port via -Port.

param(
  [int]$Port = 8080
)

$ErrorActionPreference = 'Stop'

$jar = Join-Path $PSScriptRoot '..' 'java' 'target' 'quarkus-app' 'quarkus-run.jar'
if (!(Test-Path $jar)) {
  Write-Host "Building backend first..." -ForegroundColor Yellow
  Push-Location (Join-Path $PSScriptRoot '..' 'java')
  mvn -q -DskipTests package | Out-Null
  Pop-Location
}

if (!(Test-Path $jar)) {
  Write-Error "Backend jar not found at $jar"
  exit 1
}

Write-Host "Starting Quarkus (default profile) on port $Port..." -ForegroundColor Cyan
& java -Dquarkus.http.port=$Port -jar $jar
