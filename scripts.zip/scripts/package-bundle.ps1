# Creates a minimal offline bundle zip with runnable backend and optional frontend dist
# Output: release-bundle.zip in the repo root

$ErrorActionPreference = 'Stop'
$root = Join-Path $PSScriptRoot '..'
$bundle = Join-Path $root 'bundle'

# Clean bundle dir
if (Test-Path $bundle) { Remove-Item -Recurse -Force $bundle }
New-Item -ItemType Directory -Path $bundle | Out-Null

# 1) Build backend (ensures quarkus-app exists)
Push-Location (Join-Path $root 'java')
mvn -q -DskipTests package | Out-Null
Pop-Location

# 2) Copy backend runnable
$backendOut = Join-Path $bundle 'backend'
New-Item -ItemType Directory -Path $backendOut | Out-Null
Copy-Item -Recurse -Force (Join-Path $root 'java' 'target' 'quarkus-app') $backendOut

# 3) Copy frontend dist if present (root or ./frontend)
$distRoot = Join-Path $root 'dist'
$distNested = Join-Path $root 'frontend' 'dist'
$frontendOut = Join-Path $bundle 'frontend'
if (Test-Path $distRoot) {
  New-Item -ItemType Directory -Path $frontendOut | Out-Null
  Copy-Item -Recurse -Force $distRoot $frontendOut
} elseif (Test-Path $distNested) {
  New-Item -ItemType Directory -Path $frontendOut | Out-Null
  Copy-Item -Recurse -Force $distNested $frontendOut
}

# 4) Copy keycloak realm export
$keycloakSrc = Join-Path $root 'keycloak' 'realm-export.json'
if (Test-Path $keycloakSrc) {
  $kcOut = Join-Path $bundle 'keycloak'
  New-Item -ItemType Directory -Path $kcOut | Out-Null
  Copy-Item -Force $keycloakSrc $kcOut
}

# 5) Copy helper scripts and docs
Copy-Item -Force (Join-Path $PSScriptRoot 'run-backend*.ps1') $bundle
Copy-Item -Force (Join-Path $root 'README.md') $bundle
Copy-Item -Force (Join-Path $root 'DEV_CREDENTIALS.md') -ErrorAction SilentlyContinue $bundle

# 6) Zip
$zip = Join-Path $root 'release-bundle.zip'
if (Test-Path $zip) { Remove-Item -Force $zip }
Compress-Archive -Path (Join-Path $bundle '*') -DestinationPath $zip -CompressionLevel Optimal

Write-Host "Bundle created: $zip" -ForegroundColor Green
