# Runs the Quarkus backend using the dev profile (no Keycloak/Kafka) on port 8081
# Requires Java 21 on PATH.

param(
  [int]$Port = 8081
)

$ErrorActionPreference = 'Stop'

$jar = Join-Path $PSScriptRoot '..' 'java' 'target' 'quarkus-app' 'quarkus-run.jar'
if (!(Test-Path $jar)) {
  Write-Host "Building backend first..." -ForegroundColor Yellow
  Push-Location (Join-Path $PSScriptRoot '..' 'java')
  mvn -q -DskipTests package | Out-Null
  Pop-Location
}

if (!(Test-Path $jar)) {
  Write-Error "Backend jar not found at $jar"
  exit 1
}

Write-Host "Starting Quarkus (dev profile) on port $Port..." -ForegroundColor Cyan
& java -Dquarkus.profile=dev -Dquarkus.http.port=$Port -jar $jar
