import { Routes } from '@angular/router';
import { LoginComponent } from './App/components/login/login';
import { RegisterComponent } from './App/components/Register/register';
import { DashboardAlunoComponent } from './App/components/dashboard-aluno/dashboardAluno';
import { DashboardProfessorComponent } from './App/components/dashboard-professor/dashboard-professor';
import { DashboardCoordenadorComponent } from './App/components/dashboard-coordenador/dashboard-coordenador';
import { authGuard } from './App/components/Quards/auth.quards';
import { roleGuard } from './App/components/Quards/Roles.quards';

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  
  {
    path: 'dashboard-aluno',
    canActivate: [authGuard, roleGuard(['aluno'])],
    component: DashboardAlunoComponent,
  },
  {
    path: 'dashboard-professor',
    canActivate: [authGuard, roleGuard(['professor'])],
    component: DashboardProfessorComponent,
  },
  {
    path: 'dashboard-coordenador',
    canActivate: [authGuard, roleGuard(['coordenador'])],
    component: DashboardCoordenadorComponent,
  },
  { path: '**', redirectTo: 'login' },
];