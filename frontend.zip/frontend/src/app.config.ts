import { provideHttpClient, withInterceptors } from '@angular/common/http';
import { ApplicationConfig, APP_INITIALIZER, inject, provideZoneChangeDetection } from '@angular/core';
import { provideRouter } from '@angular/router';
import { authInterceptor } from './App/components/Interceptores/authtInterceptor';
import { routes } from './app.routes';
import { AuthService } from './App/components/Services/auth.services';

function initAuth(auth: AuthService) {
  return () => auth.initKeycloak();
}

export const appConfig: ApplicationConfig = {
  providers: [
    provideZoneChangeDetection({ eventCoalescing: true }),
    provideRouter(routes),
    provideHttpClient(withInterceptors([authInterceptor])),
    { provide: APP_INITIALIZER, multi: true, deps: [AuthService], useFactory: initAuth }
  ],
};