import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../Services/auth.services';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="redirect" role="status" aria-live="polite">
      <div class="spinner" aria-hidden="true"></div>
      <p>Redirecionando para a página de login do Keycloak...</p>
    </div>
  `,
  styles: [`
    .redirect { display:flex; flex-direction:column; align-items:center; justify-content:center; gap:16px; height:70vh; color:#17324d; text-align:center; }
    .spinner { width:48px; height:48px; border:4px solid rgba(15,106,191,0.2); border-top-color:#0f6abf; border-radius:50%; animation:spin 0.8s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }
  `]
})
export class LoginComponent implements OnInit {
  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Evita redirecionar para o Keycloak quando voltando do logout em testes E2E
    try {
      const disable = localStorage.getItem('disable_kc_redirect');
      if (disable === '1') {
        localStorage.removeItem('disable_kc_redirect');
        return; // permanece na rota /login
      }
    } catch {}

    // Se já houver sessão (ex.: token em localStorage nos testes), faz o roteamento por role
    if (this.authService.isLoggedIn()) {
      const isCoord = this.authService.hasRole(['coordenador', 'COORDENADOR']);
      const isProf = this.authService.hasRole(['professor', 'PROFESSOR']);
      if (isCoord) {
        this.router.navigate(['/dashboard-coordenador']);
        return;
      }
      if (isProf) {
        this.router.navigate(['/dashboard-professor']);
        return;
      }
      this.router.navigate(['/dashboard-aluno']);
      return;
    }
    // Caso contrário, redireciona para o Keycloak (padrão)
    this.authService.login();
  }
}
