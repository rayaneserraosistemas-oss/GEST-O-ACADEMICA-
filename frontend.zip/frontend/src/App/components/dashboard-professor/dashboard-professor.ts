import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../Services/auth.services';
import { JavaDashboardService } from '../Services/java-dashboard.service';
import { ProfessorService } from '../Services/professor.service';

@Component({
  selector: 'app-dashboard-professor',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="dashboard">
      <header>
        <h1>Dashboard do Professor</h1>
        <div class="user-info">
          <span>{{userName }}</span>
          <button (click)="logout()">Sair</button>
        </div>
      </header>
      
      <nav class="tabs">
        <button [class.active]="activeTab === 'turmas'" (click)="activeTab = 'turmas'">Minhas Turmas</button>
        <button [class.active]="activeTab === 'notas'" (click)="activeTab = 'notas'">Lançar Notas</button>
        <button [class.active]="activeTab === 'relatorio'" (click)="activeTab = 'relatorio'">Relatórios</button>
      </nav>
      
      <main class="content">
        <div *ngIf="activeTab === 'turmas'" class="tab-content">
          <h2>Minhas Turmas</h2>
          <div *ngIf="loading" class="loading">Carregando...</div>
          <div class="cards">
            <div *ngFor="let turma of turmas" class="card">
              <h3>{{ turma.disciplinaNome }}</h3>
              <p><strong>Turma:</strong> {{ turma.turmaNome }}</p>
              <p><strong>Período:</strong> {{ turma.semestre }}/{{ turma.ano }}</p>
              <p><strong>Vagas:</strong> {{ turma.vagas }}</p>
              <button (click)="selectTurma(turma.turmaId)">Ver Alunos</button>
            </div>
          </div>
        </div>
        
        <div *ngIf="activeTab === 'notas'" class="tab-content">
          <h2>Lançamento de Notas</h2>
          <div *ngIf="!selectedTurma">
            <p>Selecione uma turma na aba "Minhas Turmas" para lançar notas.</p>
          </div>
          <div *ngIf="selectedTurma">
            <h3>Alunos da Turma</h3>
            <div *ngIf="loadingAlunos" class="loading">Carregando...</div>
            <table *ngIf="!loadingAlunos && alunos.length > 0">
              <thead>
                <tr><th>Aluno</th><th>Email</th><th>Ações</th></tr>
              </thead>
              <tbody>
                <tr *ngFor="let aluno of alunos">
                  <td>{{ aluno.alunoNome }}</td>
                  <td>{{ aluno.alunoEmail }}</td>
                  <td><button (click)="showNotaForm(aluno)">Lançar Nota</button></td>
                </tr>
              </tbody>
            </table>
            
            <div *ngIf="showingNotaForm" class="form-modal">
              <div class="modal-content">
                <h3>Lançar Nota - {{ selectedAluno?.alunoNome }}</h3>
                <form (ngSubmit)="lancarNota()">
                  <label>Tipo de Avaliação:</label>
                  <input [(ngModel)]="notaForm.tipo" name="tipo" required />
                  
                  <label>Nota (0-10):</label>
                  <input type="number" [(ngModel)]="notaForm.valor" name="valor" min="0" max="10" step="0.1" required />
                  
                  <label>Peso:</label>
                  <input type="number" [(ngModel)]="notaForm.peso" name="peso" min="0.1" step="0.1" />
                  
                  <label>Observação:</label>
                  <textarea [(ngModel)]="notaForm.observacao" name="observacao"></textarea>
                  
                  <div class="form-actions">
                    <button type="submit">Salvar</button>
                    <button type="button" (click)="showingNotaForm = false">Cancelar</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        
        <div *ngIf="activeTab === 'relatorio'" class="tab-content">
          <h2>Relatórios de Desempenho</h2>
          <p>Selecione uma turma para ver o relatório de desempenho.</p>
          <div class="cards">
            <div *ngFor="let turma of turmas" class="card">
              <h3>{{ turma.disciplinaNome }}</h3>
              <p>{{ turma.turmaNome }}</p>
              <button (click)="loadRelatorio(turma.turmaId)">Ver Relatório</button>
            </div>
          </div>
          
          <div *ngIf="relatorio.length > 0" class="relatorio-section">
            <h3>Relatório de Desempenho</h3>
            <table>
              <thead>
                <tr><th>Aluno</th><th>Média</th><th>Notas</th></tr>
              </thead>
              <tbody>
                <tr *ngFor="let item of relatorio">
                  <td>{{ item.alunoNome }}</td>
                  <td class="media">{{ item.media.toFixed(2) }}</td>
                  <td>{{ item.notas.length }} nota(s)</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </main>
      <section class="content" style="padding-top:0;">
        <div class="tab-content">
          <h3>Dados (API Java)</h3>
          <pre>{{ javaDashboard | json }}</pre>
        </div>
      </section>
    </div>
  `,
  styles: [`
  .dashboard { min-height: 100vh; background: #f5f5f5; }
  header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 1.5rem; display: flex; justify-content: space-between; align-items: center; }
  header h1 { margin: 0; }
  .user-info { display: flex; align-items: center; gap: 1rem; }
    .user-info button { background: white; color: #667eea; border: none; padding: 0.5rem 1rem; border-radius: 5px; cursor: pointer; }
    .tabs { background: white; display: flex; gap: 0.5rem; padding: 1rem; }
    .tabs button { padding: 0.75rem 1.5rem; border: none; background: none; cursor: pointer; }
    .tabs button.active { background: #667eea; color: white; border-radius: 5px; }
    .content { padding: 2rem; }
    .loading { text-align: center; padding: 2rem; }
    .cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem; }
    .card { background: white; padding: 1.5rem; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .card h3 { color: #667eea; margin-top: 0; }
    .card button { background: #667eea; color: white; border: none; padding: 0.5rem 1rem; border-radius: 5px; cursor: pointer; margin-top: 1rem; }
    table { width: 100%; background: white; border-collapse: collapse; margin-top: 1rem; }
    th { background: #667eea; color: white; padding: 1rem; text-align: left; }
    td { padding: 1rem; border-bottom: 1px solid #eee; }
    .form-modal { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; }
    .modal-content { background: white; padding: 2rem; border-radius: 8px; max-width: 500px; width: 90%; }
    .modal-content label { display: block; margin-top: 1rem; }
    .modal-content input, .modal-content textarea { width: 100%; padding: 0.5rem; margin-top: 0.25rem; border: 1px solid #ddd; border-radius: 4px; }
    .form-actions { display: flex; gap: 1rem; margin-top: 1rem; }
    .form-actions button { flex: 1; padding: 0.75rem; border: none; border-radius: 5px; cursor: pointer; }
    .form-actions button[type="submit"] { background: #667eea; color: white; }
    .media { font-weight: bold; color: #667eea; }
  `]
})
export class DashboardProfessorComponent implements OnInit {
  userName = '';
  activeTab = 'turmas';
  loading = true;
  loadingAlunos = false;
  
  turmas: any[] = [];
  alunos: any[] = [];
  relatorio: any[] = [];
  selectedTurma: string | null = null;
  selectedAluno: any = null;
  showingNotaForm = false;
  
  notaForm = {
    tipo: '',
    valor: 0,
    peso: 1.0,
    observacao: ''
  };

  constructor(
    private authService: AuthService,
    private javaService: JavaDashboardService,
    private professorService: ProfessorService,
  ) {}

  ngOnInit() {
    const user = this.authService.getCurrentUser();
    if (user) this.userName = user.nome;
    // Backend agora somente Java: funcionalidades antigas dependentes do Node estão desativadas.
    // this.loadTurmas();
    this.loadJavaDashboard();
  }

  loadTurmas() {
    this.loading = true;
    this.professorService.getMinhasTurmas().subscribe({
      next: (data) => { this.turmas = data; this.loading = false; },
      error: () => { this.loading = false; }
    });
  }

  selectTurma(turmaId: string) {
    this.selectedTurma = turmaId;
    this.activeTab = 'notas';
    this.loadAlunos(turmaId);
  }

  loadAlunos(turmaId: string) {
    this.loadingAlunos = true;
    this.professorService.getAlunosDaTurma(turmaId).subscribe({
      next: (data) => { this.alunos = data; this.loadingAlunos = false; },
      error: () => { this.loadingAlunos = false; }
    });
  }

  showNotaForm(aluno: any) {
    this.selectedAluno = aluno;
    this.showingNotaForm = true;
  }

  lancarNota() {
    if (!this.selectedAluno) return;
    const payload = { matriculaId: this.selectedAluno.matriculaId, ...this.notaForm };
    this.professorService.lancarNota(payload).subscribe({
      next: () => { this.showingNotaForm = false; this.notaForm = { tipo: '', valor: 0, peso: 1.0, observacao: '' }; },
      error: () => { this.showingNotaForm = false; }
    });
  }

  loadRelatorio(turmaId: string) {
    this.professorService.getRelatorio(turmaId).subscribe({
      next: (data) => this.relatorio = data,
      error: () => {}
    });
  }

  logout() {
    this.authService.logout();
  }

  // Integração com API Java
  javaDashboard: any = null;
  loadJavaDashboard() {
    this.javaService.getProfessorDashboard().subscribe({
      next: (data) => { this.javaDashboard = data; },
      error: () => { /* silencioso */ }
    });
  }
}
