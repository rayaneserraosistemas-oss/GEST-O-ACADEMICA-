import { Component, Injectable } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { LoginComponent } from '../login/login';
import { DashboardAlunoComponent } from '../dashboard-aluno/dashboardAluno';
import { DashboardProfessorComponent } from '../dashboard-professor/dashboard-professor';
import { DashboardCoordenadorComponent } from '../dashboard-coordenador/dashboard-coordenador';
import { AuthService, User } from '../Services/auth.services';
import { JavaDashboardService } from '../Services/java-dashboard.service';
import { of } from 'rxjs';

@Injectable()
class MockAuthService extends AuthService {
  override isLoggedIn(): boolean { return true; }
  override getCurrentUser(): User {
    return { id: 1, nome: 'Usuário Demo', email: 'demo@example.com', role: 'aluno' } as any;
  }
}

@Injectable()
class MockJavaDashboardService extends JavaDashboardService {
  override getAlunoDashboard() { return of({
    disciplinas: [], notas: [], historico: []
  } as any); }
}

@Component({
  selector: 'app-ui-gallery',
  standalone: true,
  imports: [CommonModule, RouterModule, LoginComponent, DashboardAlunoComponent, DashboardProfessorComponent, DashboardCoordenadorComponent],
  providers: [
    { provide: AuthService, useClass: MockAuthService },
    { provide: JavaDashboardService, useClass: MockJavaDashboardService },
  ],
  template: `
    <div class="gallery">
      <h1>UI Gallery</h1>
      <nav class="tabs">
        <button (click)="tab='login'" [class.active]="tab==='login'">Login</button>
        <button (click)="tab='aluno'" [class.active]="tab==='aluno'">Dashboard Aluno</button>
        <button (click)="tab='prof'" [class.active]="tab==='prof'">Dashboard Professor</button>
        <button (click)="tab='coord'" [class.active]="tab==='coord'">Dashboard Coordenador</button>
      </nav>

      <section class="content">
        <app-login *ngIf="tab==='login'"></app-login>
        <app-dashboard-aluno *ngIf="tab==='aluno'"></app-dashboard-aluno>
        <app-dashboard-professor *ngIf="tab==='prof'"></app-dashboard-professor>
        <app-dashboard-coordenador *ngIf="tab==='coord'"></app-dashboard-coordenador>
      </section>
    </div>
  `,
  styles: [`
    .gallery { padding: 1.5rem; }
    .tabs { display:flex; gap: .5rem; margin-bottom: 1rem; }
    .tabs button { padding: .5rem 1rem; border: 1px solid #ddd; background: #fff; border-radius: 6px; cursor: pointer; }
    .tabs button.active { background: #667eea; color: #fff; border-color: #667eea; }
    .content { background: #f8fafc; padding: 1rem; border-radius: 8px; }
  `]
})
export class UiGalleryComponent {
  tab: 'login'|'aluno'|'prof'|'coord' = 'login';
}
