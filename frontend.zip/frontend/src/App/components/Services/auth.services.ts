import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import Keycloak from 'keycloak-js';
import { keycloakConfig } from '../../../keycloak.config';

export interface User {
  id: number;
  nome: string;
  email: string;
  role: 'aluno' | 'professor' | 'coordenador';
  telefone?: string;
  endereco?: string;
  dataNascimento?: string;
  cpf?: string;
}

// Integração OIDC: token e usuário vêm do Keycloak

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();
  private keycloak?: Keycloak;
  private tokenRefreshHandle?: any;
  // fallback para login "interno" (credenciais na tela)
  private cachedToken: string | null = null;
  private cachedRefreshToken: string | null = null;
  private internalRefreshTimer: any = null;
  private refreshing = false;

  constructor(private http: HttpClient) {}

  // Inicializa Keycloak na aplicação (APP_INITIALIZER)
  initKeycloak(): Promise<void> {
    this.keycloak = new Keycloak({
      url: keycloakConfig.url,
      realm: keycloakConfig.realm,
      clientId: keycloakConfig.clientId,
    });
    return this.keycloak
      .init(keycloakConfig.initOptions as any)
      .then(authenticated => {
        if (authenticated) {
          this.updateSessionFromKeycloak();
          this.setupTokenRefresh();
        } else {
          // se não autenticado via Keycloak, tenta token armazenado (login interno)
          this.initializeFromStoredToken();
        }
      })
      .catch((err) => {
        console.error('Keycloak init error', err);
        // Em caso de erro no init, ainda assim tente inicializar com token local
        this.initializeFromStoredToken();
      });
  }

  login(): Promise<void> {
    return this.keycloak?.login() ?? Promise.resolve();
  }

  register(): Promise<void> {
    return this.keycloak?.register() ?? Promise.resolve();
  }

  // Login/registro via Provedor (Google, Microsoft/Outlook, Apple)
  // Requer que o Identity Provider esteja configurado no Keycloak com o mesmo 'alias'
  // Ex.: alias 'google', 'microsoft', 'apple'
  loginWithProvider(providerAlias: 'google' | 'microsoft' | 'apple'): Promise<void> {
    // O fluxo de 'first broker login' no Keycloak cria/associa a conta após autenticar no IdP
    return this.keycloak?.login({ idpHint: providerAlias }) ?? Promise.resolve();
  }

  logout(): void {
    this.logoutInternal();
    if (this.keycloak?.authenticated) {
      this.keycloak.logout({ redirectUri: `${window.location.origin}/login` }).catch((err) => {
        console.warn('Falha ao encerrar sessão no Keycloak', err);
        window.location.href = '/login';
      });
    } else {
      window.location.href = '/login';
    }
  }

  // Retorna token atual
  getToken(): string | null {
    // prioriza token do Keycloak, se existir
    if (this.keycloak?.token) return this.keycloak.token;
    // senão, usa o token armazenado do login interno
    if (this.cachedToken) return this.cachedToken;
    const fromStorage = localStorage.getItem('token');
    if (fromStorage) {
      this.cachedToken = fromStorage;
      return fromStorage;
    }
    return null;
  }

  getRefreshToken(): string | null {
    if (this.cachedRefreshToken) return this.cachedRefreshToken;
    const fromStorage = localStorage.getItem('refresh_token');
    if (fromStorage) {
      this.cachedRefreshToken = fromStorage;
      return fromStorage;
    }
    return null;
  }

  private updateSessionFromKeycloak() {
    if (!this.keycloak?.tokenParsed) return;
    const parsed: any = this.keycloak.tokenParsed;

    const user: User = {
      id: (parsed.sub ? Number(parsed.sub) : NaN) || 0,
      nome: parsed.name || parsed.preferred_username || 'Usuário',
      email: parsed.email || '',
      role: this.extractRole(parsed) as any,
    };
    this.currentUserSubject.next(user);

    // Provisionamento pós-login (primeiro login):
    // agora o papel (tipoUsuario) vem do perfil do Keycloak e é mapeado no token
    if (this.keycloak?.token) {
      const headers = new HttpHeaders({
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.keycloak.token}`,
      });
      this.http.post('/api/auth/provision', {}, { headers })
        .subscribe({
          next: () => {},
          error: () => {
            // Ignora erros para não bloquear a UX
          }
        });
    }
  }

  private setupTokenRefresh() {
    this.tokenRefreshHandle = setInterval(() => {
      this.keycloak?.updateToken(60).then((refreshed) => {
        if (refreshed) this.updateSessionFromKeycloak();
      }).catch(err => console.error('Erro ao renovar token', err));
    }, 30000);
  }

  private scheduleInternalRefresh() {
    if (!this.cachedToken) return;
    const parsed = this.decodeJwt(this.cachedToken);
    const exp = parsed?.exp ? parsed.exp * 1000 : null;
    if (!exp) return;
    const now = Date.now();
    // renova 60s antes de expirar, com mínimo de 5s
    const delay = Math.max(5000, exp - now - 60000);
    if (this.internalRefreshTimer) clearTimeout(this.internalRefreshTimer);
    this.internalRefreshTimer = setTimeout(() => {
      this.refreshToken().subscribe({
        next: () => this.scheduleInternalRefresh(),
        error: (e) => console.warn('Falha ao renovar token internamente', e)
      });
    }, delay);
  }

  isLoggedIn(): boolean {
    return !!this.keycloak?.authenticated || !!this.getToken();
  }

  getCurrentUser(): User | null {
    return this.currentUserSubject.value;
  }

  hasRole(role: string | string[]): boolean {
    // Suporta tanto sessão via Keycloak quanto token interno armazenado
    let parsed: any = this.keycloak?.tokenParsed;
    if (!parsed) {
      const token = this.getToken();
      parsed = this.decodeJwt(token);
    }
    if (!parsed) return false;

    const roles = this.getRolesFromToken(parsed);
    if (Array.isArray(role)) return role.some(r => roles.includes(r));
    return roles.includes(role);
  }

  private extractRole(tokenParsed: any): string {
    const roles = this.getRolesFromToken(tokenParsed);
    // heurística simples: prioriza coordenador > professor > aluno
    if (roles.includes('coordenador')) return 'coordenador';
    if (roles.includes('professor')) return 'professor';
    if (roles.includes('aluno')) return 'aluno';
    return 'aluno';
  }

  private getRolesFromToken(tokenParsed: any): string[] {
    const realmRoles: string[] = tokenParsed?.realm_access?.roles || [];
    const clientRoles: string[] = keycloakConfig.clientId && tokenParsed?.resource_access?.[keycloakConfig.clientId]?.roles || [];
    return Array.from(new Set([...(realmRoles||[]), ...(clientRoles||[])]));
  }

  // ==========================
  // Login "interno" (ROPC via backend)
  // ==========================
  loginWithCredentials(username: string, password: string): Observable<void> {
    return new Observable<void>((observer) => {
      // 1) Tenta via backend (/api/auth/login)
      this.http.post<any>('/api/auth/login', { username, password }).subscribe({
        next: (res) => {
          this.applyTokenResponse(res, username);
          this.scheduleInternalRefresh();
          observer.next();
          observer.complete();
        },
        error: () => {
          // 2) Fallback: tenta direto no Keycloak (ROPC)
          const tokenUrl = `${keycloakConfig.url.replace(/\/$/, '')}/realms/${keycloakConfig.realm}/protocol/openid-connect/token`;
          const body = new HttpParams()
            .set('grant_type', 'password')
            .set('client_id', keycloakConfig.clientId)
            .set('username', username)
            .set('password', password);
          const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
          this.http.post<any>(tokenUrl, body.toString(), { headers }).subscribe({
            next: (res2) => {
              this.applyTokenResponse(res2, username);
              this.scheduleInternalRefresh();
              observer.next();
              observer.complete();
            },
            error: (err2) => observer.error(err2),
          });
        },
      });
    });
  }

  refreshToken(): Observable<void> {
    if (this.refreshing) return of(void 0);
    const refresh = this.getRefreshToken();
    if (!refresh) return of(void 0);
    this.refreshing = true;
    return this.http.post<any>('/api/auth/refresh', { refresh_token: refresh }).pipe(
      switchMap((res) => {
        this.applyTokenResponse(res, this.currentUserSubject.value?.nome || '');
        this.scheduleInternalRefresh();
        this.refreshing = false;
        return of(void 0);
      }),
      catchError(() => {
        // fallback direto no keycloak
        const tokenUrl = `${keycloakConfig.url.replace(/\/$/, '')}/realms/${keycloakConfig.realm}/protocol/openid-connect/token`;
        const body = new HttpParams()
          .set('grant_type', 'refresh_token')
          .set('client_id', keycloakConfig.clientId)
          .set('refresh_token', refresh);
        const headers = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
        return this.http.post<any>(tokenUrl, body.toString(), { headers }).pipe(
          map((res2) => {
            this.applyTokenResponse(res2, this.currentUserSubject.value?.nome || '');
            this.scheduleInternalRefresh();
            this.refreshing = false;
            return void 0;
          }),
          catchError((e) => {
            this.refreshing = false;
            return of(void 0);
          })
        );
      })
    );
  }

  refreshTokenOnce(): Observable<boolean> {
    return this.refreshToken().pipe(map(() => !!this.getToken()));
  }

  private applyTokenResponse(res: any, usernameFallback: string) {
    const access = res?.access_token as string | undefined;
    const refresh = res?.refresh_token as string | undefined;
    if (!access) throw new Error('Resposta sem access_token');

    this.cachedToken = access;
    this.cachedRefreshToken = refresh || null;
    localStorage.setItem('token', access);
    if (refresh) localStorage.setItem('refresh_token', refresh);

    const parsed = this.decodeJwt(access);
    const user: User = {
      id: (parsed?.sub ? Number(parsed.sub) : NaN) || 0,
      nome: parsed?.name || parsed?.preferred_username || usernameFallback,
      email: parsed?.email || '',
      role: (this.extractRole(parsed) as any) || 'aluno',
    };
    this.currentUserSubject.next(user);
  }

  logoutInternal() {
    if (this.tokenRefreshHandle) {
      clearInterval(this.tokenRefreshHandle);
      this.tokenRefreshHandle = undefined;
    }
    if (this.internalRefreshTimer) clearTimeout(this.internalRefreshTimer);
    this.cachedToken = null;
    this.cachedRefreshToken = null;
    localStorage.removeItem('token');
    localStorage.removeItem('refresh_token');
    this.currentUserSubject.next(null);
  }

  private decodeJwt(token: string | null): any {
    if (!token) return null;
    const parts = token.split('.');
    if (parts.length !== 3) return null;
    try {
      const payload = atob(parts[1].replace(/-/g, '+').replace(/_/g, '/'));
      return JSON.parse(payload);
    } catch {
      return null;
    }
  }

  private initializeFromStoredToken() {
    const access = localStorage.getItem('token');
    if (!access) return;
    this.cachedToken = access;
    const refresh = localStorage.getItem('refresh_token');
    this.cachedRefreshToken = refresh;
    const parsed = this.decodeJwt(access);
    const user: User = {
      id: (parsed?.sub ? Number(parsed.sub) : NaN) || 0,
      nome: parsed?.name || parsed?.preferred_username || 'Usuário',
      email: parsed?.email || '',
      role: (this.extractRole(parsed) as any) || 'aluno',
    };
    this.currentUserSubject.next(user);
    this.scheduleInternalRefresh();
  }

  // Forgot password: redirect user to Keycloak reset credentials page
  forgotPassword() {
    const base = keycloakConfig.url.replace(/\/$/, '');
    const url = `${base}/realms/${keycloakConfig.realm}/login-actions/reset-credentials?client_id=${encodeURIComponent(keycloakConfig.clientId)}&redirect_uri=${encodeURIComponent(window.location.origin)}`;
    window.location.href = url;
  }
}
