import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class CoordenadorService {
  private base = '/api/coordenador';
  constructor(private http: HttpClient) {}

  // Usuários
  getUsuarios(role?: string): Observable<any[]> {
    const q = role ? `?role=${encodeURIComponent(role)}` : '';
    return this.http.get<any[]>(`${this.base}/usuarios${q}`);
    }
  createUsuario(data: any): Observable<any> {
    return this.http.post<any>(`${this.base}/usuarios`, data);
  }
  updateUsuario(id: string, data: any): Observable<any> {
    return this.http.put<any>(`${this.base}/usuarios/${id}`, data);
  }
  deleteUsuario(id: string): Observable<any> {
    return this.http.delete<any>(`${this.base}/usuarios/${id}`);
  }

  // Disciplinas
  getDisciplinas(cursoId?: string): Observable<any[]> {
    const q = cursoId ? `?cursoId=${encodeURIComponent(cursoId)}` : '';
    return this.http.get<any[]>(`${this.base}/disciplinas${q}`);
  }
  createDisciplina(data: any): Observable<any> {
    return this.http.post<any>(`${this.base}/disciplinas`, data);
  }
  updateDisciplina(id: string, data: any): Observable<any> {
    return this.http.put<any>(`${this.base}/disciplinas/${id}`, data);
  }
  deleteDisciplina(id: string): Observable<any> {
    return this.http.delete<any>(`${this.base}/disciplinas/${id}`);
  }

  // Matrículas
  getMatriculasPendentes(): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/matriculas/pendentes`);
  }
  atualizarStatusMatricula(id: string, status: string): Observable<any> {
    return this.http.put<any>(`${this.base}/matriculas/${id}/status`, { status });
  }

  criarMatricula(data: { alunoId: string; turmaId: string; status?: string }): Observable<any> {
    return this.http.post<any>(`${this.base}/matriculas`, data);
  }

  // Cursos
  getCursos(): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/cursos`);
  }
  createCurso(data: any): Observable<any> {
    return this.http.post<any>(`${this.base}/cursos`, data);
  }
  updateCurso(id: string, data: any): Observable<any> {
    return this.http.put<any>(`${this.base}/cursos/${id}`, data);
  }
  deleteCurso(id: string): Observable<any> {
    return this.http.delete<any>(`${this.base}/cursos/${id}`);
  }

  // Turmas
  getTurmas(): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/turmas`);
  }
  createTurma(data: any): Observable<any> {
    return this.http.post<any>(`${this.base}/turmas`, data);
  }
  updateTurma(id: string, data: any): Observable<any> {
    return this.http.put<any>(`${this.base}/turmas/${id}`, data);
  }
  deleteTurma(id: string): Observable<any> {
    return this.http.delete<any>(`${this.base}/turmas/${id}`);
  }
  getMatriculasDaTurma(id: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/turmas/${id}/matriculas`);
  }

  // Professores
  getProfessores(): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/professores`);
  }
}
