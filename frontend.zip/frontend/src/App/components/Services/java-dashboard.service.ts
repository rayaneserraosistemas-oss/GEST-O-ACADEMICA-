import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class JavaDashboardService {
  private base = '/api/dashboard';
  constructor(private http: HttpClient) {}

  getAlunoDashboard(): Observable<any> {
    return this.http.get(`${this.base}/aluno`);
  }

  getProfessorDashboard(): Observable<any> {
    return this.http.get(`${this.base}/professor`);
  }

  getCoordenadorDashboard(): Observable<any> {
    return this.http.get(`${this.base}/coordenador`);
  }
}
