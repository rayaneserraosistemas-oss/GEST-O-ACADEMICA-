import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ProfessorService {
  private base = '/api/professor';
  constructor(private http: HttpClient) {}

  getMinhasTurmas(): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/minhas-turmas`);
  }

  getAlunosDaTurma(turmaId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/turmas/${turmaId}/alunos`);
  }

  lancarNota(payload: any): Observable<any> {
    return this.http.post<any>(`${this.base}/notas`, payload);
  }

  atualizarNota(notaId: string, payload: any): Observable<any> {
    return this.http.put<any>(`${this.base}/notas/${notaId}`, payload);
  }

  getRelatorio(turmaId: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.base}/turmas/${turmaId}/relatorio`);
  }

  deletarNota(notaId: string): Observable<any> {
    return this.http.delete<any>(`${this.base}/notas/${notaId}`);
  }
}
