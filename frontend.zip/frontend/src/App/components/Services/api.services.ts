// [REMOVED]
// Este service genérico foi substituído por services específicos (ProfessorService, CoordenadorService).
export {};
