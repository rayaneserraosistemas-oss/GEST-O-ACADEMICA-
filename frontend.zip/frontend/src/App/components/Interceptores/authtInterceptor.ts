import { HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, switchMap } from 'rxjs/operators';
import { of, throwError } from 'rxjs';
import { AuthService } from '../Services/auth.services';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const router = inject(Router);
  const auth = inject(AuthService);
  const token = auth.getToken();
  
  if (token) {
    const cloned = req.clone({
      headers: req.headers.set('Authorization', `Bearer ${token}`)
    });
    return next(cloned).pipe(
      catchError((err) => {
        if (err?.status === 401 || err?.status === 403) {
          // tenta renovar automaticamente uma vez e refazer a requisição
          return auth.refreshTokenOnce().pipe(
            switchMap((ok) => {
              if (ok) {
                const newToken = auth.getToken();
                const retried = cloned.clone({
                  headers: cloned.headers.set('Authorization', `Bearer ${newToken}`)
                });
                return next(retried);
              }
              router.navigate(['/login']);
              return throwError(() => err);
            })
          );
        }
        return throwError(() => err);
      })
    );
  }
  
  return next(req).pipe(
    catchError((err) => {
      if (err?.status === 401 || err?.status === 403) {
        // Sem token anexado: tenta refresh (se existir) e repete
        return auth.refreshTokenOnce().pipe(
          switchMap((ok) => {
            if (ok) {
              const newToken = auth.getToken();
              const retried = req.clone({ headers: req.headers.set('Authorization', `Bearer ${newToken}`) });
              return next(retried);
            }
            router.navigate(['/login']);
            return throwError(() => err);
          })
        );
      }
      return throwError(() => err);
    })
  );
};
