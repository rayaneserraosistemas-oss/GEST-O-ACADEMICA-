import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../Services/auth.services';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="redirect" role="status" aria-live="polite">
      <div class="spinner" aria-hidden="true"></div>
      <p>Redirecionando para a página de registro do Keycloak...</p>
    </div>
  `,
  styles: [`
    .redirect { display:flex; flex-direction:column; align-items:center; justify-content:center; gap:16px; height:70vh; color:#17324d; text-align:center; }
    .spinner { width:48px; height:48px; border:4px solid rgba(15,106,191,0.2); border-top-color:#0f6abf; border-radius:50%; animation:spin 0.8s linear infinite; }
    @keyframes spin { to { transform: rotate(360deg); } }
  `]
})
export class RegisterComponent implements OnInit {
  constructor(
    private authService: AuthService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Redireciona direto para a tela de registro do Keycloak
    this.authService.register();
  }
}
