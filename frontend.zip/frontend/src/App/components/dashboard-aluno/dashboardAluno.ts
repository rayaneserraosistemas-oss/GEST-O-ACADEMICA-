import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { JavaDashboardService } from '../Services/java-dashboard.service';
import { AuthService } from '../Services/auth.services';

@Component({
  selector: 'app-dashboard-aluno',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="dashboard">
      <header>
        <h1>Dashboard do Aluno</h1>
        <div class="user-info">
          <span>Bem-vindo, {{ userName }}</span>
          <button (click)="logout()">Sair</button>
        </div>
      </header>
      
      <nav class="tabs">
        <button [class.active]="activeTab === 'disciplinas'" (click)="activeTab = 'disciplinas'">
          Minhas Disciplinas
        </button>
        <button [class.active]="activeTab === 'notas'" (click)="activeTab = 'notas'">
          Minhas Notas
        </button>
        <button [class.active]="activeTab === 'historico'" (click)="activeTab = 'historico'">
          Histórico
        </button>
        <button [class.active]="activeTab === 'perfil'" (click)="activeTab = 'perfil'">
          Meu Perfil
        </button>
      </nav>
      
      <main class="content">
        <div *ngIf="activeTab === 'disciplinas'" class="tab-content">
          <h2>Minhas Disciplinas</h2>
          <div *ngIf="loading" class="loading">Carregando...</div>
          <div *ngIf="!loading && disciplinas.length === 0" class="empty">
            Você não está matriculado em nenhuma disciplina.
          </div>
          <div class="cards">
            <div *ngFor="let disc of disciplinas" class="card">
              <h3>{{ disc.disciplinaNome }}</h3>
              <p><strong>Código:</strong> {{ disc.disciplinaCodigo }}</p>
              <p><strong>Turma:</strong> {{ disc.turmaNome }}</p>
              <p><strong>Professor:</strong> {{ disc.professorNome }}</p>
              <p><strong>Período:</strong> {{ disc.semestre }}/{{ disc.ano }}</p>
              <p><strong>Carga Horária:</strong> {{ disc.cargaHoraria }}h</p>
              <span class="badge">{{ disc.status }}</span>
            </div>
          </div>
        </div>
        
        <div *ngIf="activeTab === 'notas'" class="tab-content">
          <h2>Minhas Notas</h2>
          <div *ngIf="loadingNotas" class="loading">Carregando...</div>
          <div *ngIf="!loadingNotas && notas.length === 0" class="empty">
            Nenhuma nota lançada ainda.
          </div>
          <div class="table-container">
            <table *ngIf="!loadingNotas && notas.length > 0">
              <thead>
                <tr>
                  <th>Disciplina</th>
                  <th>Turma</th>
                  <th>Avaliação</th>
                  <th>Nota</th>
                  <th>Peso</th>
                  <th>Professor</th>
                  <th>Data</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let nota of notas">
                  <td>{{ nota.disciplinaNome }}</td>
                  <td>{{ nota.turmaNome }}</td>
                  <td>{{ nota.tipo }}</td>
                  <td class="nota-valor">{{ nota.valor }}</td>
                  <td>{{ nota.peso }}</td>
                  <td>{{ nota.professorNome }}</td>
                  <td>{{ nota.dataLancamento | date:'dd/MM/yyyy' }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        <div *ngIf="activeTab === 'historico'" class="tab-content">
          <h2>Histórico de Matrículas</h2>
          <div *ngIf="loadingHistorico" class="loading">Carregando...</div>
          <div *ngIf="!loadingHistorico && historico.length === 0" class="empty">
            Nenhum histórico encontrado.
          </div>
          <div class="table-container">
            <table *ngIf="!loadingHistorico && historico.length > 0">
              <thead>
                <tr>
                  <th>Disciplina</th>
                  <th>Código</th>
                  <th>Turma</th>
                  <th>Período</th>
                  <th>Status</th>
                  <th>Data Matrícula</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let item of historico">
                  <td>{{ item.disciplinaNome }}</td>
                  <td>{{ item.disciplinaCodigo }}</td>
                  <td>{{ item.turmaNome }}</td>
                  <td>{{ item.semestre }}/{{ item.ano }}</td>
                  <td><span class="badge" [class]="item.status">{{ item.status }}</span></td>
                  <td>{{ item.dataMatricula | date:'dd/MM/yyyy' }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        
        <div *ngIf="activeTab === 'perfil'" class="tab-content">
          <h2>Meu Perfil</h2>
          <div class="profile-info">
            <p><strong>Nome:</strong> {{ perfil.nome }}</p>
            <p><strong>Email:</strong> {{ perfil.email }}</p>
            <p><strong>CPF:</strong> {{ perfil.cpf || 'Não informado' }}</p>
            <p><strong>Telefone:</strong> {{ perfil.telefone || 'Não informado' }}</p>
            <p><strong>Data de Nascimento:</strong> {{ perfil.dataNascimento || 'Não informado' }}</p>
            <p><strong>Endereço:</strong> {{ perfil.endereco || 'Não informado' }}</p>
          </div>
        </div>
      </main>
      <section class="content" style="padding-top:0;">
        <div class="tab-content">
          <h3>Dados (API Java)</h3>
          <pre>{{ javaDashboard | json }}</pre>
        </div>
      </section>
    </div>
  `,
  styles: [`
    .dashboard { min-height: 100vh; background: #f5f5f5; }
    header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 1.5rem; display: flex; justify-content: space-between; align-items: center; }
    header h1 { margin: 0; font-size: 1.8rem; }
    .user-info { display: flex; align-items: center; gap: 1rem; }
    .user-info button { background: white; color: #667eea; border: none; padding: 0.5rem 1rem; border-radius: 5px; cursor: pointer; }
    .tabs { background: white; display: flex; gap: 0.5rem; padding: 1rem; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .tabs button { padding: 0.75rem 1.5rem; border: none; background: none; cursor: pointer; border-radius: 5px; }
    .tabs button.active { background: #667eea; color: white; }
    .content { padding: 2rem; }
    .tab-content h2 { color: #333; margin-bottom: 1.5rem; }
    .loading, .empty { text-align: center; padding: 2rem; color: #666; }
    .cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 1.5rem; }
    .card { background: white; padding: 1.5rem; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .card h3 { color: #667eea; margin-top: 0; }
    .card p { margin: 0.5rem 0; color: #666; }
    .badge { display: inline-block; padding: 0.25rem 0.75rem; border-radius: 12px; background: #28a745; color: white; font-size: 0.875rem; }
    .badge.pendente { background: #ffc107; }
    .badge.reprovada { background: #dc3545; }
    .table-container { background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    table { width: 100%; border-collapse: collapse; }
    th { background: #667eea; color: white; padding: 1rem; text-align: left; }
    td { padding: 1rem; border-bottom: 1px solid #eee; }
    .nota-valor { font-weight: bold; color: #667eea; }
    .profile-info { background: white; padding: 2rem; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
    .profile-info p { margin: 1rem 0; color: #666; }
  `]
})
export class DashboardAlunoComponent implements OnInit {
  userName = '';
  activeTab = 'disciplinas';
  loading = true;
  loadingNotas = true;
  loadingHistorico = true;
  
  disciplinas: any[] = [];
  notas: any[] = [];
  historico: any[] = [];
  perfil: any = {};

  constructor(
    private authService: AuthService,
    private javaService: JavaDashboardService,
  ) {}

  ngOnInit() {
    const user = this.authService.getCurrentUser();
    if (user) {
      this.userName = user.nome;
      this.perfil = user;
    }
    
    // Backend agora só em Java: dados agregados via endpoint do dashboard
    this.loadJavaDashboard();
  }
  // Chamadas específicas (disciplinas/notas/historico) serão atendidas por endpoints Java dedicados.

  logout() {
    this.authService.logout();
  }

  // Integração com API Java (quarkus)
  javaDashboard: any = null;
  loadJavaDashboard() {
    this.javaService.getAlunoDashboard().subscribe({
      next: (data) => { this.javaDashboard = data; },
      error: () => { /* silencioso */ }
    });
  }
}
