import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../Services/auth.services';
import { JavaDashboardService } from '../Services/java-dashboard.service';
import { CoordenadorService } from '../Services/coordenador.service';

@Component({
  selector: 'app-dashboard-coordenador',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="dashboard">
      <header>
        <h1>Dashboard do Coordenador</h1>
        <div class="user-info">
          <span>{{ userName }}</span>
          <button (click)="logout()">Sair</button>
        </div>
      </header>
      
      <nav class="tabs">
        <button [class.active]="activeTab === 'usuarios'" (click)="activeTab = 'usuarios'; loadUsuarios()">Usuários</button>
        <button [class.active]="activeTab === 'disciplinas'" (click)="activeTab = 'disciplinas'; loadDisciplinas()">Disciplinas</button>
        <button [class.active]="activeTab === 'matriculas'" (click)="activeTab = 'matriculas'; loadMatriculas()">Matrículas</button>
      </nav>
      
      <main class="content">
        <div *ngIf="activeTab === 'usuarios'" class="tab-content">
          <div class="header-actions">
            <h2>Gerenciar Usuários</h2>
            <button (click)="showUsuarioForm = true">+ Novo Usuário</button>
          </div>
          
          <table *ngIf="usuarios.length > 0">
            <thead>
              <tr><th>Nome</th><th>Email</th><th>Perfil</th><th>CPF</th><th>Status</th><th>Ações</th></tr>
            </thead>
            <tbody>
              <tr *ngFor="let user of usuarios">
                <td>{{ user.nome }}</td>
                <td>{{ user.email }}</td>
                <td><span class="badge">{{ user.role }}</span></td>
                <td>{{ user.cpf || '-' }}</td>
                <td>{{ user.ativo ? 'Ativo' : 'Inativo' }}</td>
                <td>
                  <button (click)="editUsuario(user)">Editar</button>
                  <button (click)="deleteUsuario(user.id)">Desativar</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <div *ngIf="activeTab === 'disciplinas'" class="tab-content">
          <div class="header-actions">
            <h2>Gerenciar Disciplinas</h2>
            <button (click)="showDisciplinaForm = true">+ Nova Disciplina</button>
          </div>
          
          <table *ngIf="disciplinas.length > 0">
            <thead>
              <tr><th>Nome</th><th>Código</th><th>Carga Horária</th><th>Professor</th><th>Ações</th></tr>
            </thead>
            <tbody>
              <tr *ngFor="let disc of disciplinas">
                <td>{{ disc.nome }}</td>
                <td>{{ disc.codigo }}</td>
                <td>{{ disc.cargaHoraria }}h</td>
                <td>{{ disc.professorNome || 'Sem professor' }}</td>
                <td>
                  <button (click)="editDisciplina(disc)">Editar</button>
                  <button (click)="deleteDisciplina(disc.id)">Desativar</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        
        <div *ngIf="activeTab === 'matriculas'" class="tab-content">
          <h2>Aprovar Matrículas</h2>
          
          <table *ngIf="matriculas.length > 0">
            <thead>
              <tr><th>Aluno</th><th>Disciplina</th><th>Turma</th><th>Período</th><th>Data</th><th>Ações</th></tr>
            </thead>
            <tbody>
              <tr *ngFor="let mat of matriculas">
                <td>{{ mat.alunoNome }}</td>
                <td>{{ mat.disciplinaNome }}</td>
                <td>{{ mat.turmaNome }}</td>
                <td>{{ mat.semestre }}/{{ mat.ano }}</td>
                <td>{{ mat.dataMatricula | date:'dd/MM/yyyy' }}</td>
                <td>
                  <button (click)="aprovarMatricula(mat.matriculaId, 'aprovada')">Aprovar</button>
                  <button (click)="aprovarMatricula(mat.matriculaId, 'reprovada')">Reprovar</button>
                </td>
              </tr>
            </tbody>
          </table>
          <p *ngIf="matriculas.length === 0">Nenhuma matrícula pendente.</p>
        </div>
      </main>
      
      <div *ngIf="showUsuarioForm" class="modal">
        <div class="modal-content">
          <h3>{{ editingUsuario ? 'Editar' : 'Novo' }} Usuário</h3>
          <form (ngSubmit)="saveUsuario()">
            <label>Nome:</label>
            <input [(ngModel)]="usuarioForm.nome" name="nome" required />
            
            <label>Email:</label>
            <input type="email" [(ngModel)]="usuarioForm.email" name="email" required />
            
            <label>Perfil:</label>
            <select [(ngModel)]="usuarioForm.role" name="role">
              <option value="aluno">Aluno</option>
              <option value="professor">Professor</option>
              <option value="coordenador">Coordenador</option>
            </select>
            
            <label>CPF:</label>
            <input [(ngModel)]="usuarioForm.cpf" name="cpf" />
            
            <label>Telefone:</label>
            <input [(ngModel)]="usuarioForm.telefone" name="telefone" />
            
            <div *ngIf="!editingUsuario">
              <label>Senha:</label>
              <input type="password" [(ngModel)]="usuarioForm.senha" name="senha" required />
            </div>
            
            <div class="form-actions">
              <button type="submit">Salvar</button>
              <button type="button" (click)="cancelForm()">Cancelar</button>
            </div>
          </form>
        </div>
      </div>
      
      <div *ngIf="showDisciplinaForm" class="modal">
        <div class="modal-content">
          <h3>{{ editingDisciplina ? 'Editar' : 'Nova' }} Disciplina</h3>
          <form (ngSubmit)="saveDisciplina()">
            <label>Nome:</label>
            <input [(ngModel)]="disciplinaForm.nome" name="nome" required />
            
            <label>Código:</label>
            <input [(ngModel)]="disciplinaForm.codigo" name="codigo" required />
            
            <label>Carga Horária:</label>
            <input type="number" [(ngModel)]="disciplinaForm.cargaHoraria" name="cargaHoraria" required />
            
            <label>Descrição:</label>
            <textarea [(ngModel)]="disciplinaForm.descricao" name="descricao"></textarea>
            
            <label>Professor:</label>
            <select [(ngModel)]="disciplinaForm.professorId" name="professorId">
              <option [value]="null">Sem professor</option>
              <option *ngFor="let prof of professores" [value]="prof.id">{{ prof.nome }}</option>
            </select>
            
            <div class="form-actions">
              <button type="submit">Salvar</button>
              <button type="button" (click)="cancelForm()">Cancelar</button>
            </div>
          </form>
        </div>
      </div>
      <section class="content" style="padding-top:0;">
        <div class="tab-content">
          <h3>Dados (API Java)</h3>
          <pre>{{ javaDashboard | json }}</pre>
        </div>
      </section>
    </div>
  `,
  styles: [`
  .dashboard { min-height: 100vh; background: #f5f5f5; }
  header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 1.5rem; display: flex; justify-content: space-between; align-items: center; }
  header h1 { margin: 0; }
  .user-info { display: flex; align-items: center; gap: 1rem; }
  .user-info button { background: white; color: #667eea; border: none; padding: 0.5rem 1rem; border-radius: 5px; cursor: pointer; }
    .tabs { background: white; display: flex; gap: 0.5rem; padding: 1rem; }
    .tabs button { padding: 0.75rem 1.5rem; border: none; background: none; cursor: pointer; }
    .tabs button.active { background: #667eea; color: white; border-radius: 5px; }
    .content { padding: 2rem; }
    .header-actions { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem; }
    .header-actions button { background: #28a745; color: white; border: none; padding: 0.75rem 1.5rem; border-radius: 5px; cursor: pointer; }
    table { width: 100%; background: white; border-collapse: collapse; }
    th { background: #667eea; color: white; padding: 1rem; text-align: left; }
    td { padding: 1rem; border-bottom: 1px solid #eee; }
    td button { margin-right: 0.5rem; padding: 0.5rem 1rem; border: none; border-radius: 4px; cursor: pointer; }
    td button:first-of-type { background: #667eea; color: white; }
    td button:last-of-type { background: #dc3545; color: white; }
    .badge { padding: 0.25rem 0.75rem; border-radius: 12px; background: #667eea; color: white; font-size: 0.875rem; }
    .modal { position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); display: flex; align-items: center; justify-content: center; }
    .modal-content { background: white; padding: 2rem; border-radius: 8px; max-width: 500px; width: 90%; max-height: 90vh; overflow-y: auto; }
    .modal-content label { display: block; margin-top: 1rem; font-weight: bold; }
    .modal-content input, .modal-content select, .modal-content textarea { width: 100%; padding: 0.5rem; margin-top: 0.25rem; border: 1px solid #ddd; border-radius: 4px; }
    .form-actions { display: flex; gap: 1rem; margin-top: 1.5rem; }
    .form-actions button { flex: 1; padding: 0.75rem; border: none; border-radius: 5px; cursor: pointer; }
    .form-actions button[type="submit"] { background: #667eea; color: white; }
  `]
})
export class DashboardCoordenadorComponent implements OnInit {
  userName = '';
  activeTab = 'usuarios';
  
  usuarios: any[] = [];
  disciplinas: any[] = [];
  matriculas: any[] = [];
  professores: any[] = [];
  
  showUsuarioForm = false;
  showDisciplinaForm = false;
  editingUsuario: any = null;
  editingDisciplina: any = null;
  
  usuarioForm: any = { nome: '', email: '', role: 'aluno', cpf: '', telefone: '', senha: '' };
  disciplinaForm: any = { nome: '', codigo: '', cargaHoraria: 0, descricao: '', professorId: null };

  constructor(
    private authService: AuthService,
    private javaService: JavaDashboardService,
    private coordenadorService: CoordenadorService,
  ) {}

  ngOnInit() {
    const user = this.authService.getCurrentUser();
    if (user) this.userName = user.nome;
    // Backend agora somente Java: funcionalidades antigas dependentes do Node estão desativadas.
    // this.loadUsuarios();
    // this.loadProfessores();
    this.loadJavaDashboard();
  }

  loadUsuarios() {
    this.coordenadorService.getUsuarios().subscribe({
      next: (data) => this.usuarios = data,
      error: () => {}
    });
  }

  loadDisciplinas() {
    this.coordenadorService.getDisciplinas().subscribe({
      next: (data) => this.disciplinas = data,
      error: () => {}
    });
  }

  loadMatriculas() {
    this.coordenadorService.getMatriculasPendentes().subscribe({
      next: (data) => this.matriculas = data,
      error: () => {}
    });
  }

  loadProfessores() {
    this.coordenadorService.getProfessores().subscribe({
      next: (data) => this.professores = data,
      error: () => {}
    });
  }

  editUsuario(user: any) {
    this.editingUsuario = user;
    this.usuarioForm = { ...user };
    this.showUsuarioForm = true;
  }

  deleteUsuario(id: string) {
    if (confirm('Deseja desativar este usuário?')) {
      this.coordenadorService.deleteUsuario(id).subscribe({
        next: () => this.loadUsuarios(),
        error: () => {}
      });
    }
  }

  saveUsuario() {
    const action = this.editingUsuario
      ? this.coordenadorService.updateUsuario(this.editingUsuario.id, this.usuarioForm)
      : this.coordenadorService.createUsuario(this.usuarioForm);
    action.subscribe({
      next: () => { this.cancelForm(); this.loadUsuarios(); },
      error: () => {}
    });
  }

  editDisciplina(disc: any) {
    this.editingDisciplina = disc;
    this.disciplinaForm = { ...disc };
    this.showDisciplinaForm = true;
  }

  deleteDisciplina(id: string) {
    if (confirm('Deseja desativar esta disciplina?')) {
      this.coordenadorService.deleteDisciplina(id).subscribe({
        next: () => this.loadDisciplinas(),
        error: () => {}
      });
    }
  }

  saveDisciplina() {
    const action = this.editingDisciplina
      ? this.coordenadorService.updateDisciplina(this.editingDisciplina.id, this.disciplinaForm)
      : this.coordenadorService.createDisciplina(this.disciplinaForm);
    action.subscribe({
      next: () => { this.cancelForm(); this.loadDisciplinas(); },
      error: () => {}
    });
  }

  aprovarMatricula(id: string, status: string) {
    this.coordenadorService.atualizarStatusMatricula(id, status).subscribe({
      next: () => this.loadMatriculas(),
      error: () => {}
    });
  }

  cancelForm() {
    this.showUsuarioForm = false;
    this.showDisciplinaForm = false;
    this.editingUsuario = null;
    this.editingDisciplina = null;
    this.usuarioForm = { nome: '', email: '', role: 'aluno', cpf: '', telefone: '', senha: '' };
    this.disciplinaForm = { nome: '', codigo: '', cargaHoraria: 0, descricao: '', professorId: null };
  }

  logout() {
    this.authService.logout();
  }

  // Integração com API Java
  javaDashboard: any = null;
  loadJavaDashboard() {
    this.javaService.getCoordenadorDashboard().subscribe({
      next: (data) => { this.javaDashboard = data; },
      error: () => { /* silencioso */ }
    });
  }
}
