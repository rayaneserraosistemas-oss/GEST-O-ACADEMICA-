// Legacy config file not used. Kept intentionally empty to avoid build errors.
export {};
