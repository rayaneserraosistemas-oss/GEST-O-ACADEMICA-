// Ajuste estes valores conforme seu Keycloak
export const keycloakConfig = {
  url: 'http://localhost:8180/', // base do servidor Keycloak (ou URL externa) - evitar colisão com backend 8080
  realm: 'gestao-academica',     // seu realm
  clientId: 'frontend',          // o client do SPA
  // fluxo recomendado para SPA
  initOptions: {
    onLoad: 'check-sso',         // não força login na carga
    pkceMethod: 'S256',
    silentCheckSsoRedirectUri: window.location.origin + '/silent-check-sso.html'
  }
};
