# Frontend (Angular)

Este diretório contém apenas o frontend da aplicação. A documentação completa (stack, arquitetura, Keycloak, backend, E2E e CI) está no README da raiz do repositório.

- Documentação completa: consulte `../README.md`.

## Rodar localmente (desenvolvimento)

```powershell
npm install
npm run start:test
```

Acesse http://localhost:4200/login

## Testes

- Unitários (Karma):
```powershell
npm test
```

- End‑to‑End (Playwright):
```powershell
npm run e2e
```

Para incluir o smoke test da API, consulte o README na raiz (variável `API_SMOKE`).